#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>

#include <random>
#include <string>

using namespace geode::prelude;

namespace {
    // Random generator used to decide whether a death call is ignored.
    std::mt19937& rng() {
        static std::mt19937 engine{ std::random_device{}() };
        return engine;
    }

    int getProtectionChance() {
        auto value = Mod::get()->getSettingValue<std::string>("survivalChance");

        try {
            int chance = std::stoi(value);
            if (chance < 0) return 0;
            if (chance > 100) return 100;
            return chance;
        } catch (...) {
            return 100;
        }
    }
}

// IMPORTANT:
// This is a prototype of probabilistic death protection, not true click
// correction. It skips selected calls to PlayLayer::destroyPlayer.
// Some hazards/triggers may use other death paths or leave the player in
// an invalid collision state. Android 2.2074 compilation/runtime still
// needs to be verified on a real Geode Android installation.

class $modify(CCP_PlayLayer, PlayLayer) {
    void destroyPlayer(PlayerObject* player, GameObject* object) {
        const bool enabled =
            Mod::get()->getSettingValue<bool>("enabled");

        if (enabled) {
            const int chance = getProtectionChance();
            std::uniform_int_distribution<int> roll(1, 100);

            if (roll(rng()) <= chance) {
                log::debug(
                    "Click Corrector Pro: skipped death call (chance={}%)",
                    chance
                );
                return;
            }
        }

        PlayLayer::destroyPlayer(player, object);
    }
};
